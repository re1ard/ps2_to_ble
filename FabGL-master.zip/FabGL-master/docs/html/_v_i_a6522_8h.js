var _v_i_a6522_8h =
[
    [ "VIA6522", "classfabgl_1_1_v_i_a6522.html", null ],
    [ "VIA6522Port", "_v_i_a6522_8h.html#ga69838990f93c3301289776790e4fc0e0", [
      [ "PA", "_v_i_a6522_8h.html#gga69838990f93c3301289776790e4fc0e0a06f6a489209115c5cef3f45036aad3ec", null ],
      [ "PB", "_v_i_a6522_8h.html#gga69838990f93c3301289776790e4fc0e0acd203ccd68b84de1c5df8fd890e104e0", null ],
      [ "CA1", "_v_i_a6522_8h.html#gga69838990f93c3301289776790e4fc0e0ac93bf9a243a391a65da5b60116ee9a5c", null ],
      [ "CA2", "_v_i_a6522_8h.html#gga69838990f93c3301289776790e4fc0e0a3702f3bfbd91df0d6105cbd8b8d8b963", null ],
      [ "CB1", "_v_i_a6522_8h.html#gga69838990f93c3301289776790e4fc0e0ac479bbda96996453098aaa0687a9197e", null ],
      [ "CB2", "_v_i_a6522_8h.html#gga69838990f93c3301289776790e4fc0e0a96d495d6079a5d50e1b6bc3fc9255f09", null ]
    ] ]
];