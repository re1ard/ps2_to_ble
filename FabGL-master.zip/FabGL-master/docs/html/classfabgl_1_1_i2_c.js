var classfabgl_1_1_i2_c =
[
    [ "I2C", "classfabgl_1_1_i2_c_a93f66e29e22bca7a9f5d8e3d5af2d6a2.html#a93f66e29e22bca7a9f5d8e3d5af2d6a2", null ],
    [ "begin", "classfabgl_1_1_i2_c_abdd72a91fee181ca1b9eb05120e60a28.html#abdd72a91fee181ca1b9eb05120e60a28", null ],
    [ "getMaxBufferLength", "classfabgl_1_1_i2_c_a798669caf759c63cfa1e67cfb9d35874.html#a798669caf759c63cfa1e67cfb9d35874", null ],
    [ "read", "classfabgl_1_1_i2_c_aee6d332047f3429253a95c94c59cccd9.html#aee6d332047f3429253a95c94c59cccd9", null ],
    [ "write", "classfabgl_1_1_i2_c_a5683609bed861f2c075c25d935029e3f.html#a5683609bed861f2c075c25d935029e3f", null ]
];