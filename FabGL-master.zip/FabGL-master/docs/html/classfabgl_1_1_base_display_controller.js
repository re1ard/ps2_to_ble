var classfabgl_1_1_base_display_controller =
[
    [ "colorsCount", "classfabgl_1_1_base_display_controller_a332051b311781945a020928d50825adc.html#a332051b311781945a020928d50825adc", null ],
    [ "controllerType", "classfabgl_1_1_base_display_controller_aa4e745f41c133010dbc7f6f599aa74a2.html#aa4e745f41c133010dbc7f6f599aa74a2", null ],
    [ "getScreenHeight", "classfabgl_1_1_base_display_controller_a0872427e4a351bb3590e8d00096e9cba.html#a0872427e4a351bb3590e8d00096e9cba", null ],
    [ "getScreenWidth", "classfabgl_1_1_base_display_controller_a749df909b39fd096bf6e2813f2f5324c.html#a749df909b39fd096bf6e2813f2f5324c", null ],
    [ "getViewPortHeight", "classfabgl_1_1_base_display_controller_a5308b6853d3778845649f08832e96535.html#a5308b6853d3778845649f08832e96535", null ],
    [ "getViewPortWidth", "classfabgl_1_1_base_display_controller_a69dd55b31e9c284aeec6f2b91a8da525.html#a69dd55b31e9c284aeec6f2b91a8da525", null ]
];