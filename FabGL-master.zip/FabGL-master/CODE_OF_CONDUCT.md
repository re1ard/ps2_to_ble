# No pull requests please!

Instead open an issue and explain your suggestion or bugfix.

Thank you!
